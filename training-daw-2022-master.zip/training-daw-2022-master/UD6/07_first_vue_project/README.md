# Instructions

run vue create first_vue_project from command line :)