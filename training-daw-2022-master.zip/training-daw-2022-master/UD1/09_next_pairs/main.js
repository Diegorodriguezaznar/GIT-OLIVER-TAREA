const assert = require('assert').strict;

function nextPairs(value) {
}

assert.deepStrictEqual(nextPairs(3), [2,4])
assert.deepStrictEqual(nextPairs(4), [2,6])