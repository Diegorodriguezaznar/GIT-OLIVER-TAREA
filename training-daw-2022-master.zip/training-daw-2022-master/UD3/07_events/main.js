window.onload = function(e) {
    console.log('documento cargado')
}